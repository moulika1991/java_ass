public class joinString{
    public static void main(String args[])
    {
        String str1="hello ";
        String str2="how are you?";
        var result=str1.concat(str2);
        System.out.println(result);
    }
}