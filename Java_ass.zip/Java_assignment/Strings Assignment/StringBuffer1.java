public class StringBuffer1 {
    public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sbf1= new StringBuffer("StringBuffer ");
		StringBuffer sbf2= new StringBuffer("is a peer class of String ");
		sbf1.append(sbf2);
		StringBuffer sbf3= new StringBuffer("that provides much of ");
		sbf1.append(sbf3);
		StringBuffer sbf4= new StringBuffer("the functionality of Strings ");
		sbf1.append(sbf4);
		System.out.println(sbf1);

	}
}
