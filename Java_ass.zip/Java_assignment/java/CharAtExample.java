public class CharAtExample {
     
        public static void main(String args[]){  
        String name="javatpoint";  
        char ch=name.charAt(4);//returns the char value at the 4th index  
        System.out.println(ch);  
        }}  
    
